package database

import (
	"fmt"
	"time"

	"golang.org/x/crypto/bcrypt"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"motorcycle-garage-inventory/backend/internal/models"
)

func Connect(url string) (*gorm.DB, error) {
	db, err := gorm.Open(postgres.Open(url), &gorm.Config{})
	if err != nil { return nil, err }
	sqlDB, err := db.DB()
	if err != nil { return nil, err }
	sqlDB.SetMaxOpenConns(20); sqlDB.SetMaxIdleConns(5); sqlDB.SetConnMaxLifetime(time.Hour)
	return db, nil
}
func Migrate(db *gorm.DB) error {
	return db.AutoMigrate(&models.User{}, &models.Part{}, &models.Sale{}, &models.ServiceJob{})
}
func SeedDemo(db *gorm.DB) error {
	var count int64
	db.Model(&models.User{}).Where("email = ?", "manager@garage.local").Count(&count)
	if count > 0 { return nil }
	hash, err := bcrypt.GenerateFromPassword([]byte("Garage123!"), bcrypt.DefaultCost); if err != nil { return err }
	manager := models.User{Name:"Demo Manager", Email:"manager@garage.local", PasswordHash:string(hash), Role:"manager"}
	mechanic := models.User{Name:"Demo Mechanic", Email:"mechanic@garage.local", PasswordHash:string(hash), Role:"mechanic"}
	if err := db.Create(&manager).Error; err != nil { return err }
	if err := db.Create(&mechanic).Error; err != nil { return err }
	parts := []models.Part{
		{SKU:"OIL-10W40",Name:"Oli Mesin 10W-40",Category:"Pelumas",Brand:"Motul",Location:"Rak A-01",Stock:12,MinStock:3,UnitPrice:85000},
		{SKU:"SPK-CR7",Name:"Busi NGK CR7",Category:"Pengapian",Brand:"NGK",Location:"Rak B-02",Stock:2,MinStock:3,UnitPrice:28000},
		{SKU:"BRK-PAD-01",Name:"Kampas Rem Depan",Category:"Rem",Brand:"Aspira",Location:"Rak C-01",Stock:7,MinStock:3,UnitPrice:65000},
		{SKU:"FLT-AIR-01",Name:"Filter Udara",Category:"Filter",Brand:"AHM",Location:"Rak A-03",Stock:3,MinStock:3,UnitPrice:42000},
	}
	for _, p := range parts { if err := db.Create(&p).Error; err != nil { return err } }
	now := time.Now()
	jobs := []models.ServiceJob{
		{WorkOrder:"WO-DEMO-001",CustomerName:"Budi Santoso",Motorcycle:"Honda Vario 160",PlateNumber:"AB 1234 CD",Complaint:"Servis berkala dan ganti oli",MechanicID:mechanic.ID,Status:"in_progress"},
		{WorkOrder:"WO-DEMO-002",CustomerName:"Siti Aminah",Motorcycle:"Yamaha NMAX",PlateNumber:"AB 5678 EF",Complaint:"Pemeriksaan rem",MechanicID:mechanic.ID,Status:"queued"},
	}
	for i := range jobs { if jobs[i].Status == "in_progress" { jobs[i].StartedAt = &now }; if err := db.Create(&jobs[i]).Error; err != nil { return fmt.Errorf("seed service: %w",err) } }
	return nil
}
