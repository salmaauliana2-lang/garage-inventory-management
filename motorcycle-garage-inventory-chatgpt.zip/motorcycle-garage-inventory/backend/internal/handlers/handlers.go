package handlers

import (
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v5"
	"golang.org/x/crypto/bcrypt"
	"gorm.io/gorm"
	"motorcycle-garage-inventory/backend/internal/config"
	"motorcycle-garage-inventory/backend/internal/models"
)

type Handler struct { DB *gorm.DB; Config config.Config }
func New(db *gorm.DB, cfg config.Config) *Handler { return &Handler{DB:db, Config:cfg} }
func fail(c *gin.Context, code int, msg string) { c.JSON(code, gin.H{"error":msg}) }
func currentUserID(c *gin.Context) uint { v, _ := c.Get("userID"); id, _ := v.(uint); return id }

type authInput struct { Name string `json:"name"`; Email string `json:"email"`; Password string `json:"password"`; Role string `json:"role"` }
func (h *Handler) Register(c *gin.Context) {
	var in authInput; if c.ShouldBindJSON(&in) != nil { fail(c,400,"invalid request body"); return }
	in.Name = strings.TrimSpace(in.Name); in.Email = strings.ToLower(strings.TrimSpace(in.Email))
	if in.Name == "" || in.Email == "" || len(in.Password) < 8 { fail(c,400,"name/email required and password must be at least 8 characters"); return }
	role := "mechanic" // Public registration cannot grant manager privileges.
	hash, err := bcrypt.GenerateFromPassword([]byte(in.Password), bcrypt.DefaultCost); if err != nil { fail(c,500,"could not hash password"); return }
	u := models.User{Name:in.Name,Email:in.Email,PasswordHash:string(hash),Role:role}
	if err := h.DB.Create(&u).Error; err != nil { fail(c,409,"email already registered or invalid user"); return }
	c.JSON(201, gin.H{"user":u})
}
func (h *Handler) Login(c *gin.Context) {
	var in authInput; if c.ShouldBindJSON(&in) != nil { fail(c,400,"invalid request body"); return }
	var u models.User
	if err := h.DB.Where("email = ?", strings.ToLower(strings.TrimSpace(in.Email))).First(&u).Error; err != nil { fail(c,401,"email or password is incorrect"); return }
	if bcrypt.CompareHashAndPassword([]byte(u.PasswordHash), []byte(in.Password)) != nil { fail(c,401,"email or password is incorrect"); return }
	hours := h.Config.JWTExpiresHours; if hours < 1 { hours = 24 }
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{"user_id":u.ID,"role":u.Role,"exp":time.Now().Add(time.Duration(hours)*time.Hour).Unix(),"iat":time.Now().Unix()})
	signed, err := token.SignedString([]byte(h.Config.JWTSecret)); if err != nil { fail(c,500,"could not create token"); return }
	c.JSON(200, gin.H{"token":signed,"user":u})
}
func (h *Handler) Logout(c *gin.Context) { c.JSON(200,gin.H{"message":"logged out; discard the token on the client"}) }
func (h *Handler) Me(c *gin.Context) { var u models.User; if h.DB.First(&u,currentUserID(c)).Error != nil { fail(c,404,"user not found"); return }; c.JSON(200,gin.H{"user":u}) }

func (h *Handler) ListParts(c *gin.Context) {
	q := h.DB.Model(&models.Part{})
	search := strings.TrimSpace(c.Query("search"))
	if search != "" { like := "%"+search+"%"; q = q.Where("name ILIKE ? OR sku ILIKE ? OR category ILIKE ? OR location ILIKE ? OR brand ILIKE ?",like,like,like,like,like) }
	if c.Query("low_stock") == "true" { q = q.Where("stock <= min_stock") }
	var parts []models.Part
	if err := q.Order("name ASC").Find(&parts).Error; err != nil { fail(c,500,"failed to list parts"); return }
	c.JSON(200,gin.H{"data":parts})
}
type partInput struct { SKU string `json:"sku" binding:"required"`; Name string `json:"name" binding:"required"`; Category string `json:"category"`; Brand string `json:"brand"`; Location string `json:"location" binding:"required"`; Stock int `json:"stock"`; MinStock int `json:"min_stock"`; UnitPrice int64 `json:"unit_price"` }
func (h *Handler) CreatePart(c *gin.Context) {
	var in partInput; if c.ShouldBindJSON(&in)!=nil || in.Stock<0 || in.MinStock<0 || in.UnitPrice<0 { fail(c,400,"invalid part data"); return }
	if in.MinStock == 0 { in.MinStock = 3 }
	p:=models.Part{SKU:strings.TrimSpace(in.SKU),Name:strings.TrimSpace(in.Name),Category:in.Category,Brand:in.Brand,Location:in.Location,Stock:in.Stock,MinStock:in.MinStock,UnitPrice:in.UnitPrice}
	if err:=h.DB.Create(&p).Error; err!=nil { fail(c,409,"SKU already exists or data is invalid"); return }; c.JSON(201,gin.H{"data":p})
}
func (h *Handler) GetPart(c *gin.Context) { var p models.Part; if h.DB.First(&p,c.Param("id")).Error!=nil { fail(c,404,"part not found"); return }; c.JSON(200,gin.H{"data":p}) }
func (h *Handler) UpdatePart(c *gin.Context) {
	var p models.Part; if h.DB.First(&p,c.Param("id")).Error!=nil { fail(c,404,"part not found"); return }
	var in partInput; if c.ShouldBindJSON(&in)!=nil || in.Stock<0 || in.MinStock<0 || in.UnitPrice<0 { fail(c,400,"invalid part data"); return }
	if in.MinStock==0 { in.MinStock=3 }
	p.SKU=in.SKU; p.Name=in.Name; p.Category=in.Category; p.Brand=in.Brand; p.Location=in.Location; p.Stock=in.Stock; p.MinStock=in.MinStock; p.UnitPrice=in.UnitPrice
	if err:=h.DB.Save(&p).Error; err!=nil { fail(c,409,"could not update part; check SKU uniqueness"); return }; c.JSON(200,gin.H{"data":p})
}
func (h *Handler) DeletePart(c *gin.Context) { if err:=h.DB.Delete(&models.Part{},c.Param("id")).Error; err!=nil { fail(c,500,"could not delete part"); return }; c.JSON(200,gin.H{"message":"part deleted"}) }

type saleInput struct { PartID uint `json:"part_id"`; Quantity int `json:"quantity"` }
func (h *Handler) CreateSale(c *gin.Context) {
	var in saleInput; if c.ShouldBindJSON(&in)!=nil || in.PartID==0 || in.Quantity<1 { fail(c,400,"part_id and positive quantity are required"); return }
	var sale models.Sale
	err:=h.DB.Transaction(func(tx *gorm.DB) error {
		var p models.Part; if err:=tx.Set("gorm:query_option","FOR UPDATE").First(&p,in.PartID).Error; err!=nil { return err }
		if p.Stock<in.Quantity { return gorm.ErrInvalidData }
		p.Stock-=in.Quantity; if err:=tx.Save(&p).Error; err!=nil { return err }
		sale=models.Sale{PartID:p.ID,Quantity:in.Quantity,UnitPrice:p.UnitPrice,Total:p.UnitPrice*int64(in.Quantity),SoldAt:time.Now(),CreatedBy:currentUserID(c)}
		return tx.Create(&sale).Error
	})
	if err!=nil { fail(c,400,"sale failed: part may not exist or stock is insufficient"); return }
	h.DB.Preload("Part").First(&sale,sale.ID); c.JSON(201,gin.H{"data":sale})
}
func (h *Handler) ListSales(c *gin.Context) { var rows []models.Sale; q:=h.DB.Preload("Part").Order("sold_at DESC").Limit(200); if err:=q.Find(&rows).Error; err!=nil { fail(c,500,"failed to list sales"); return }; c.JSON(200,gin.H{"data":rows}) }

type serviceInput struct { CustomerName string `json:"customer_name"`; Motorcycle string `json:"motorcycle"`; PlateNumber string `json:"plate_number"`; Complaint string `json:"complaint"`; MechanicID uint `json:"mechanic_id"` }
func (h *Handler) ListServices(c *gin.Context) { var rows []models.ServiceJob; if err:=h.DB.Preload("Mechanic").Order("created_at DESC").Find(&rows).Error; err!=nil { fail(c,500,"failed to list services"); return }; c.JSON(200,gin.H{"data":rows}) }
func (h *Handler) CreateService(c *gin.Context) {
	var in serviceInput; if c.ShouldBindJSON(&in)!=nil || strings.TrimSpace(in.CustomerName)=="" || strings.TrimSpace(in.Motorcycle)=="" { fail(c,400,"customer_name and motorcycle are required"); return }
	if in.MechanicID==0 { in.MechanicID=currentUserID(c) }
	var mechanic models.User; if h.DB.First(&mechanic,in.MechanicID).Error!=nil { fail(c,400,"mechanic not found"); return }
	job:=models.ServiceJob{WorkOrder:"WO-"+time.Now().Format("20060102-150405")+"-"+strconv.Itoa(int(time.Now().UnixNano()%1000)),CustomerName:in.CustomerName,Motorcycle:in.Motorcycle,PlateNumber:in.PlateNumber,Complaint:in.Complaint,MechanicID:in.MechanicID,Status:"queued"}
	if err:=h.DB.Create(&job).Error; err!=nil { fail(c,500,"could not create service job"); return }; h.DB.Preload("Mechanic").First(&job,job.ID); c.JSON(201,gin.H{"data":job})
}
type statusInput struct { Status string `json:"status"` }
func (h *Handler) UpdateServiceStatus(c *gin.Context) {
	var in statusInput; if c.ShouldBindJSON(&in)!=nil { fail(c,400,"status is required"); return }
	valid:=map[string]bool{"queued":true,"in_progress":true,"waiting_parts":true,"completed":true,"cancelled":true}; if !valid[in.Status] { fail(c,400,"unsupported status"); return }
	var job models.ServiceJob; if h.DB.First(&job,c.Param("id")).Error!=nil { fail(c,404,"service job not found"); return }
	now:=time.Now(); job.Status=in.Status
	if in.Status=="in_progress" && job.StartedAt==nil { job.StartedAt=&now }
	if in.Status=="completed" { job.CompletedAt=&now }
	if in.Status!="completed" { job.CompletedAt=nil }
	if err:=h.DB.Save(&job).Error; err!=nil { fail(c,500,"could not update status"); return }; h.DB.Preload("Mechanic").First(&job,job.ID); c.JSON(200,gin.H{"data":job})
}
func (h *Handler) Dashboard(c *gin.Context) {
	var partCount, lowCount, activeJobs int64
	h.DB.Model(&models.Part{}).Count(&partCount)
	h.DB.Model(&models.Part{}).Where("stock <= min_stock").Count(&lowCount)
	h.DB.Model(&models.ServiceJob{}).Where("status IN ?",[]string{"queued","in_progress","waiting_parts"}).Count(&activeJobs)
	type DaySale struct { Day string `json:"day"`; Total int64 `json:"total"`; Quantity int64 `json:"quantity"` }
	var chart []DaySale
	h.DB.Model(&models.Sale{}).Select("to_char(sold_at, 'YYYY-MM-DD') as day, COALESCE(SUM(total),0) as total, COALESCE(SUM(quantity),0) as quantity").Where("sold_at >= ?",time.Now().AddDate(0,0,-6).Format("2006-01-02")).Group("to_char(sold_at, 'YYYY-MM-DD')").Order("day ASC").Scan(&chart)
	var revenue int64; h.DB.Model(&models.Sale{}).Where("sold_at >= ?",time.Now().Format("2006-01-02")).Select("COALESCE(SUM(total),0)").Scan(&revenue)
	var lowParts []models.Part; h.DB.Where("stock <= min_stock").Order("stock ASC").Limit(8).Find(&lowParts)
	c.JSON(http.StatusOK,gin.H{"stats":gin.H{"parts":partCount,"low_stock":lowCount,"active_services":activeJobs,"today_revenue":revenue},"sales_chart":chart,"low_stock_parts":lowParts})
}
