# GarageFlow — Motorcycle Garage Inventory Management

MVP aplikasi manajemen inventory bengkel motor: pencarian lokasi sparepart, alert stok minimum, chart omzet harian, service board, register/login/logout, role manager/mechanic.

## Stack
- Backend: Go, Gin, GORM, PostgreSQL, JWT, bcrypt
- Frontend: React + Vite, React Router, Axios, Recharts
- API: REST `/api/v1`
- Version control: Git

## Prasyarat
- Go 1.23+
- Node.js 20+
- Docker + Docker Compose (atau PostgreSQL 16 lokal)

## Jalankan lokal

### 1. Database
Di root project:

```bash
docker compose up -d db
```

### 2. Konfigurasi backend
```bash
cp .env.example .env
```
Ubah `JWT_SECRET` menjadi secret acak yang kuat sebelum penggunaan non-demo. Variabel `.env` dibaca oleh shell/IDE; Go tidak otomatis membaca file `.env`, jadi export variabel sebelum menjalankan server.

Linux/macOS:
```bash
set -a; source .env; set +a
go mod download
go run ./backend/cmd/api
```

Windows PowerShell:
```powershell
Copy-Item .env.example .env
$env:APP_PORT="8080"
$env:DATABASE_URL="postgres://garage:garage_dev_password@localhost:5432/garage_inventory?sslmode=disable"
$env:JWT_SECRET="ganti-dengan-secret-acak-yang-panjang"
$env:SEED_DEMO="true"
go mod download
go run ./backend/cmd/api
```

GORM otomatis menjalankan schema migration saat API start. Demo data hanya ditambahkan jika akun manager demo belum ada. Health check: http://localhost:8080/health

### 3. Frontend
Buka terminal baru:
```bash
cd frontend
npm install
npm run dev
```
Buka http://localhost:5173

Jika API bukan di `http://localhost:8080/api/v1`, buat `frontend/.env`:
```env
VITE_API_URL=http://localhost:8080/api/v1
```

## Akun demo
- Pengelola: `manager@garage.local` / `Garage123!`
- Montir: `mechanic@garage.local` / `Garage123!`

**Ganti/hapus akun demo dan password sebelum deploy.** Registrasi publik sengaja hanya membuat role `mechanic`; jangan membuka endpoint pembuatan manager ke publik. Buat manager pertama melalui seed atau proses admin tepercaya.

## Fitur
- **Inventory:** cari nama, SKU, kategori, brand, dan lokasi gudang; filter stok menipis; pengelola dapat menambah/mengubah/menghapus data lewat API.
- **Alert stok:** status low-stock jika `stock <= min_stock`; default `min_stock = 3`.
- **Penjualan:** catat transaksi, kurangi stok, simpan total penjualan; transaksi memakai DB transaction.
- **Dashboard:** total sparepart, low-stock, service aktif, omzet hari ini, chart omzet 7 hari terakhir.
- **Service board:** queued, in progress, waiting parts, completed, cancelled.
- **Auth:** register/login/logout, bcrypt, JWT dengan expiry, route middleware. Frontend menyimpan token/user di `localStorage`.

## Endpoint REST
Semua endpoint selain register/login/health membutuhkan `Authorization: Bearer <token>`.

| Method | Endpoint | Akses |
|---|---|---|
| POST | `/api/v1/auth/register` | publik; role selalu mechanic |
| POST | `/api/v1/auth/login` | publik |
| POST | `/api/v1/auth/logout` | login |
| GET | `/api/v1/auth/me` | login |
| GET | `/api/v1/parts?search=oli&low_stock=true` | login |
| GET | `/api/v1/parts/:id` | login |
| POST | `/api/v1/parts` | manager |
| PUT | `/api/v1/parts/:id` | manager |
| DELETE | `/api/v1/parts/:id` | manager |
| GET/POST | `/api/v1/sales` | login |
| GET/POST | `/api/v1/services` | login |
| PATCH | `/api/v1/services/:id/status` | login |
| GET | `/api/v1/dashboard` | login |

Contoh login:
```bash
curl -X POST http://localhost:8080/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"manager@garage.local","password":"Garage123!"}'
```

## Git
```bash
git init
git add .
git commit -m "feat: initial GarageFlow inventory management MVP"
git branch -M main
```

## Catatan sebelum production
- Token di localStorage rentan dicuri jika ada XSS. Untuk production pertimbangkan HttpOnly Secure SameSite cookie, CSP, HTTPS, rate limiting, audit log, backup DB, dan refresh/revocation strategy.
- Logout JWT stateless hanya menghapus token di browser; token curian tetap valid sampai expiry. Tambahkan denylist/token version jika perlu revoke di server.
- Atur CORS berdasarkan domain frontend aktual, gunakan secrets manager, batasi akses PostgreSQL, serta buat backup dan migration terkontrol.
- Saat ini service assignment sederhana dan chart hanya memvisualisasikan omzet yang sudah tercatat. Tambahkan test otomatis dan validasi bisnis lebih mendalam sebelum produksi.
